// 1/2.
// Foydalanuvchidan yoshni so’raydigan dasturni tuzing. Yosh 50 dan y uqori bo’lsa, dastur “Siz kattasiz” deb chiqarib berishi kerak. Yosh 50 dan past bo’lsa “Siz yoshsiz” deb chiqarib berishi kerak.

// let age = 40

// if (age > 50) {
//    console.log('Siz kattasiz')
// } else {
//    console.log('Siz yoshsiz')
// }




// (2)/11.
// loop keyingi qadamga o'tsin agar i 5 ga teng bo'lsa

// for (i = 0; i < 10; i++) {
//    if (i == 5) {
//       continue
//    }
//    console.log(i)
// }




// (3)/14 ??
// loop ishlating (farqi yo'q qaysi) Konsolga chiqarish 10 11 9 12 8 13 7 14 6 15 5 16 4 17 3 18 2 19 1 20 0





// (4)/22.

// bar() funksiyasi bor u 3 ta sonni bir biriga ko'paytirib qaytarishi kerak
// ushbu vazifani bajaruvchi kod yozing
// html

function myfun() {
   let a = document.getElementById("number1").value;
   let b = document.getElementById("number2").value;
   let c = document.getElementById("number3").value;
   document.getElementById("result").innerHTML = a * b * c;
}


